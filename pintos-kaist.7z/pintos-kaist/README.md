### DISCLAIMER: We will not use this project for Operating Systems and Lab (CS330) by Youngjin Kwon from 2025 Fall Semester.

Brand new pintos for Operating Systems and Lab (CS330), KAIST, by Youngjin Kwon.

The manual is available at https://casys-kaist.github.io/pintos-kaist/.

